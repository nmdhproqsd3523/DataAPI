#!/usr/bin/env python
from multiprocessing.pool import ThreadPool

import time
def process(i):
    print i
    time.sleep(1)
    return

print type(['a','b'])
pool = ThreadPool(processes=20)  
pool.map(process, (ii for ii in ['a','b','c','d']))
pool.close() 
