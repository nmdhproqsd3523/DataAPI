#!/bin/bash

# user A
#"privkey" : "c755b46d32c802e546f8bbd8c60255e2d1b00fbebf49c7c5ae7f16bbe343f235",
#"pubkey" : "f1b124ca2145aa688d77db4c37fe4bbee153af5e35baf4acc44dac41aa0f24df"
#"addr" : 1vwj0zaj1nh6w9b7mq8tnxbtkw6z4qzhq9kdqf3b8n92j3jh4p7ryae5d
# pow sign
# "privkey" : "9027e5a1ebb83fefaf30f4186efa290ac57d07539e681b730d3888b0891e5b57",
# "pubkey" : "c72d0fdbf189749d8ed2204ae54507ba0bd3a2371a683dd8d5dc5d7589442cef"

# user B
#"privkey" : "5ee0d584b8348e8a9b500dd1f53e3ed34ad46b841036fd3df86d0a3f7111e881",
#"pubkey" : "198ace0df9757f6c065800af6b4cc0dc0e7609bfbd3a6ae9bf23d08ceb1e7ca7"
#"addr" : 1mxy1xtwct0hvztba7ayvy2bp1vec0k3bnw05g1kcfxtzj3eeh8cvp9d7

# user C
# "privkey" : "55160ae5e94f3e2f796fae0aaf071255e6ce5f1a4e2708c2fa46ee43282c9450",
# "pubkey" : "25658f0aca8d44dd41a812f9d9fc72375d5bcb91f682f24810c20e1b8fe3509e"
#"addr" : 1ks8e73rv1v110j7jgbv93jtvbmvq5z6sz49aggex8j6wm2mfcmjm2k49

# all pow config
#cryptonightaddress=1vwj0zaj1nh6w9b7mq8tnxbtkw6z4qzhq9kdqf3b8n92j3jh4p7ryae5d
#cryptonightkey=9027e5a1ebb83fefaf30f4186efa290ac57d07539e681b730d3888b0891e5b57

if [ $# != 2 ]; then
    echo "Too few parameters; exit"
    exit
else
    echo $1
fi

#    then
if [ $1 == "init" ]; then
    bigbang importprivkey c755b46d32c802e546f8bbd8c60255e2d1b00fbebf49c7c5ae7f16bbe343f235 123
    bigbang unlockkey f1b124ca2145aa688d77db4c37fe4bbee153af5e35baf4acc44dac41aa0f24df 123
    bigbang addnewtemplate mint '{"mint": "c72d0fdbf189749d8ed2204ae54507ba0bd3a2371a683dd8d5dc5d7589442cef", "spent": "1vwj0zaj1nh6w9b7mq8tnxbtkw6z4qzhq9kdqf3b8n92j3jh4p7ryae5d"}'

    bigbang importprivkey 5ee0d584b8348e8a9b500dd1f53e3ed34ad46b841036fd3df86d0a3f7111e881 123
    bigbang unlockkey 198ace0df9757f6c065800af6b4cc0dc0e7609bfbd3a6ae9bf23d08ceb1e7ca7 123

    bigbang importprivkey 55160ae5e94f3e2f796fae0aaf071255e6ce5f1a4e2708c2fa46ee43282c9450 123
    bigbang unlockkey 25658f0aca8d44dd41a812f9d9fc72375d5bcb91f682f24810c20e1b8fe3509e 123

else
    if [ $2 == "A" ]; then
        echo "run sendfrom A -> B"
        while true; do 
            sleep 2
            bigbang sendfrom 20g00vc3d0wp4hd6fwpkeqnsh475pctr7t5mfy08a8h100czgkxjx6gyp 1mxy1xtwct0hvztba7ayvy2bp1vec0k3bnw05g1kcfxtzj3eeh8cvp9d7 3
        done
    elif [ $2 == "B" ]; then
        echo "run sendfrom B -> C"
        while true; do 
            sleep 2
            bigbang sendfrom 1mxy1xtwct0hvztba7ayvy2bp1vec0k3bnw05g1kcfxtzj3eeh8cvp9d7 1ks8e73rv1v110j7jgbv93jtvbmvq5z6sz49aggex8j6wm2mfcmjm2k49 2
        done
    elif [ $2 == "C" ]; then
        echo "run sendfrom C -> A"
        while true; do 
            sleep 2
            bigbang sendfrom 1ks8e73rv1v110j7jgbv93jtvbmvq5z6sz49aggex8j6wm2mfcmjm2k49 1vwj0zaj1nh6w9b7mq8tnxbtkw6z4qzhq9kdqf3b8n92j3jh4p7ryae5d 1
        done
    else
        echo "exit run"
    fi
fi