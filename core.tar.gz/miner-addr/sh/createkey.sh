#!/bin/bash

#bigbang -daemon 
#sudo apt install jq

cat pubkey.txt | while read line
do
    rpccmd="bigbang getpubkeyaddress ${line:1:64}"
    res=`$rpccmd`
    echo $res >> addr.txt
done
exit
rm -rf keypari.json
rm -rf pubkey.txt
rm -rf addr.txt

for i in {1..100}  
do 
    echo $i 
    bigbang makekeypair >> keypari.json
done

cat keypari.json | jq '.pubkey' > pubkey.txt

cat pubkey.txt | while read line
do
    rpccmd="bigbang getpubkeyaddress ${line:1:64}"
    res=`$rpccmd`
    echo $res >> addr.txt
done

echo "OK"
