#!/bin/bash

bigbang getblockcount
bigbang listpeer
bigbang gettxpool
cat ~/.bigbang/logs/*.log | grep "Remove Peer"
cat ~/.bigbang/logs-collector/*.log | grep "Remove Peer"