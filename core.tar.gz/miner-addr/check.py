#!/usr/bin/python
# -*- coding: UTF-8 -*-

import requests,json,os,time,datetime
#import calendar
from requests.exceptions import ReadTimeout
from requests.exceptions import HTTPError
from requests.exceptions import RequestException
import traceback
import pymysql
from multiprocessing.pool import ThreadPool
import threading

mutex = threading.Lock()

db = pymysql.connect(host="127.0.0.1", port=3306, user="root", password="123456", db="bigbang")

def ExecSql(sql):
    try:
        mutex.acquire()
        cursor = db.cursor()
        cursor.execute(sql)
        db.commit()
        mutex.release()
        return cursor.lastrowid
    except Exception,e:
        mutex.release()
        print e
        return 0


def IsHave(addr,pool):
    with db.cursor() as cursor :
        mutex.acquire()
        sql = "select id from `Check` where addr = '%s' and pool = '%s'" % (addr,pool)
        cursor.execute(sql)
        db.commit()
        mutex.release()
        return cursor.fetchone()

#ExecSql("delete from `Check`")
sql = "SELECT pool,addr,SUM(miner) m FROM `Address` GROUP BY pool,addr"
cursor = db.cursor()
cursor.execute(sql)
info = cursor.fetchall()

proxies = { 'http': 'socks5://localhost:1080', 'https': 'socks5://localhost:1080'}
num = 0
def process(row):
    global num
    num = num + 1
    api = 'http://%s/stats_address?address=%s&longpoll=true' % (row[0][:-4] + "8117",row[1])
    #if IsHave(row[1],row[0]) != None:
    #    return
    while (True):
        print api
        try:
            data = requests.get(api,proxies=proxies,timeout=15).text
            datajson = json.loads(data)
            print "...", time.strftime('%Y-%m-%d %H:%M:%S')
            if datajson.has_key("workers"):
                for obj in datajson["workers"]:
                    sql = "insert `Check`(addr,miner,pool,hash_rate,work_num)values('%s','%s','%s',%s,%s)" % (row[1],obj["name"],row[0],obj["hashrate_24h"],row[2])
                    ExecSql(sql)
            else:
                sql = "insert `Check`(addr,pool,work_num)values('%s','%s',%s)" % (row[1],row[0],row[2])
                ExecSql(sql)
                print num, row[1]
        except Exception as e: 
            #requests.exceptions.Timeout as e:
            #traceback.print_exc()
	        print(str(e))
        else:    
            return

pool = ThreadPool(processes=20) 
pool.map(process, (row for row in info))
pool.close()