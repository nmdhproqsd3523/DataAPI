#!/usr/bin/python
# -*- coding: UTF-8 -*-

from openpyxl import load_workbook
import sys
import pymysql

connection = pymysql.connect(host="127.0.0.1", port=3306, user="root", password="123456", db="bigbang")

def ExecSql(sql):
    try:
        cursor = connection.cursor()
        cursor.execute(sql)
        connection.commit()
        return cursor.lastrowid
    except Exception,e:
        return 0


wb = load_workbook('./data/data.xlsx')

a_sheet = wb.get_sheet_by_name('12-19')

for num in range(1,201):
    addr = a_sheet['A' + str(num)]
    miner = a_sheet['B' + str(num)]
    pool = a_sheet['C' + str(num)]
    sql = "insert Address(addr,miner,pool,master,remarks) values('%s',%s,'%s','yi xiu','2019-12-19')" % (addr.value,miner.value,pool.value)
    ExecSql(sql)
    print num,sql
