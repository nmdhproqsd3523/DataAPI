#!/usr/bin/python
# -*- coding: UTF-8 -*-
import commands

import pymysql

db = pymysql.connect(host="127.0.0.1", port=3306, user="root", password="123456", db="bigbang")

def ExecSql(sql):
    try:
        cursor = db.cursor()
        cursor.execute(sql)
        db.commit()
        return cursor.lastrowid
    except Exception,e:
        print e
        return 0


f = open("./pubkey_addr/pubkey.txt")
lines = f.readlines()
for line in lines:
    line = line[1:65]
    if len(line) == 64:
        retcode = commands.getoutput("bigbang getpubkeyaddress %s" % line)
        sql = "update Address set pub = '%s' where  addr = '%s'" % (line,retcode)
        ExecSql(sql)
        print line,retcode
f.close()
