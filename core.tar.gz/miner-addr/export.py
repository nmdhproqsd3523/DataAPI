#!/usr/bin/python
# -*- coding: UTF-8 -*-
import sys
import pymysql
import commands
import json
import os
import time
from openpyxl import Workbook
from openpyxl.reader.excel import load_workbook


db = pymysql.connect(host="127.0.0.1", port=3306, user="root", password="123456", db="bigbang")

def ExportData():
    excelPath = os.path.join(os.getcwd(), 'data')
    nameTime = time.strftime('%Y-%m-%d_%H-%M-%S')
    excelName = nameTime + '.xlsx'
    ExcelFullName= os.path.join(excelPath,excelName)
    print ExcelFullName

    wb = Workbook()

    ws = wb.active

    tableTitle = ['pub', 'addr', 'miner', 'balance']

    for col in range(len(tableTitle)):
        c = col + 1
        ws.cell(row=1, column=c).value = tableTitle[col]

    tableValues = []

    sql = "SELECT pub, addr,sum(miner) m FROM `Address` where pub is not null GROUP BY pub,addr"
    cursor = db.cursor()
    cursor.execute(sql)
    info = cursor.fetchall()
    balance = 0
    for row in info:
        retcode = commands.getoutput("bigbang listunspent %s" % row[1])
        datajson = json.loads(retcode)
        balance = balance + datajson["sum"]
        tableValues.append([row[0],row[1],row[2],datajson["sum"]])
        print balance

    for row in range(len(tableValues)):
        ws.append(tableValues[row])
    wb.save(filename=ExcelFullName)
    return ExcelFullName

ExportData()
